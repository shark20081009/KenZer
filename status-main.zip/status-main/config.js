const fs = require('fs');
if (fs.existsSync('config.env')) require('dotenv').config({ path: './config.env' });

function convertToBool(text, fault = 'true') {
    return text === fault ? true : false;
}
module.exports = {
OWNER: process.env.OWNER === undefined ? `94762898541` : process.env.OWNER,
PREFIX: process.env.PREFIX === undefined ? '.' : process.env.PREFIX,
SESSION_ID: process.env.SESSION_ID === undefined ? 'PRABATH-MD~djlgHSCI#gMSywq0G_dz9Kw_So67mCE-rCaRPSpxTG83Q4oB1ywE' : process.env.SESSION_ID,
EMOJI: [
      "💝",  "💟",  "🩷",  "🩵",  "💌",
]
};
